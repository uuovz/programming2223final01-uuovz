# Quelltextverzeichnis
Die Struktur der Unterverzeichnisse dieses Verzeichnisses spiegelt die Paketstruktur der Abgabe wider.
Sollten bereits Dateien (z.B. Klassen oder Interfaces) in Paketen vorgegeben sein, so dürfen diese nicht in ein anderes Paket verschoben werden.
Sollten bereits Methodensignaturen in eben genannten Dateien vorgegeben sein, so dürfen auch diese nicht verändert werden.
