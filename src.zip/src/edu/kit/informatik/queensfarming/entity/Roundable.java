package edu.kit.informatik.queensfarming.entity;

public interface Roundable {
    void nextRound();
}
