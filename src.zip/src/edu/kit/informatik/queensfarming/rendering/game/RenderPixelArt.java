package edu.kit.informatik.queensfarming.rendering.game;

import edu.kit.informatik.queensfarming.rendering.Render;

public class RenderPixelArt extends Render {
    private static final String PIXEL_ART
        =
        "                           _.-^-._    .--.    " + NEW_LINE
            +
            "                        .-'   _   '-. |__|    " + NEW_LINE
            +
            "                       /     |_|     \\|  |    " + NEW_LINE
            +
            "                      /               \\  |    " + NEW_LINE
            +
            "                     /|     _____     |\\ |    " + NEW_LINE
            +
            "                      |    |==|==|    |  |    " + NEW_LINE
            +
            "  |---|---|---|---|---|    |--|--|    |  |    " + NEW_LINE
            +
            "  |---|---|---|---|---|    |==|==|    |  |    " + NEW_LINE
            +
            "^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^" + NEW_LINE
            +
            "^^^^^^^^^^^^^^^ QUEENS FARMING ^^^^^^^^^^^^^^^" + NEW_LINE
            +
            "^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^";

    public String render() {
        return PIXEL_ART;
    }
}
