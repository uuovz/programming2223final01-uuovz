package edu.kit.informatik.queensfarming.rendering.engine;

public class RenderBuyLand {

}
