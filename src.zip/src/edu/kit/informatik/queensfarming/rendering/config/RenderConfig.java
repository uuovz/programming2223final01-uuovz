package edu.kit.informatik.queensfarming.rendering.config;

import edu.kit.informatik.queensfarming.rendering.Render;

public class RenderConfig extends Render {

    private static final String OUTPUT_PLAYERNUMBER = "How many players?";
    private static final String OUTPUT_PLAYERNAME = "Enter the name of player %d:";
    private static final String OUTPUT_INITAL_GOLD = "With how much gold should each player start?";
    private static final String OUTPUT_FINAL_GOLD = "With how much gold should a player win?";
    private static final String OUTPUT_SEED = "Please enter the seed used to shuffle the tiles:";
    private int phase = 0;
    private int currentPlayer = 0;

    @Override
    public String render() {
        String output;
        if (phase == 5) {
            output = OUTPUT_PLAYERNUMBER;
        } else if (phase == 4) {
            output = String.format(OUTPUT_PLAYERNAME, this.currentPlayer);
        } else if (phase == 3) {
            output = OUTPUT_INITAL_GOLD;
        } else if (phase == 2) {
            output = OUTPUT_FINAL_GOLD;
        } else if (phase == 1) {
            output = OUTPUT_SEED;
        } else {
            output = null;
        }
        return output;
    }

    public void setPhase(int phase) {
        this.phase = phase;
    }

    public void setCurrentPlayer(int currentPlayer) {
        this.currentPlayer = currentPlayer;
    }
}
