package edu.kit.informatik.queensfarming.rendering;

/**
 *
 */
public interface Renderable {
    String render();
}
