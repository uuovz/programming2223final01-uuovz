package edu.kit.informatik.queensfarming.ui;

public enum IoType {
    INPUT,
    OUTPUT

}
