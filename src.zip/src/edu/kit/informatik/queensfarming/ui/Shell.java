package edu.kit.informatik.queensfarming.ui;

import edu.kit.informatik.queensfarming.GameException;
import edu.kit.informatik.queensfarming.game.Config;
import edu.kit.informatik.queensfarming.game.GameEngine;
import edu.kit.informatik.queensfarming.rendering.Renderable;
import edu.kit.informatik.queensfarming.rendering.game.RenderPixelArt;

import java.util.Scanner;

/**
 * The type Shell.
 *
 * @author uuovz
 * @version 1.0
 */
public class Shell {

    /**
     *
     */
    public static final String QUIT_ARGUMENT = "quit";
    /**
     * An empty string used for some outputs.
     */
    public static final String EMPTY_STRING = "";

    /**
     * Start.
     */
    public void start() {
        Renderable renderPixelArt = new RenderPixelArt();
        System.out.println(renderPixelArt.render());
        Config config = new Config();
        ParserConfig parserConfig = new ParserConfig(config);
        Scanner scanner = new Scanner(System.in);
        //setup queensframing config
        while (parserConfig.isActive()) {
            if (parserConfig.getCurrentIoType() == IoType.INPUT) {
                try {
                    String userInput = scanner.nextLine();
                    parserConfig.parseConfig(userInput);
                } catch (GameException exception) {
                    System.err.println(exception.getMessage());
                }
            } else {
                System.out.println(parserConfig.getOutputStream());
            }
        }
        if (!parserConfig.quitted()) {
            GameEngine gameEngine = new GameEngine(config);
            while (gameEngine.isActive()) {
                if (gameEngine.getIoType() == IoType.INPUT) {
                    try {
                        String userInput = scanner.nextLine();
                        String output = ParserGame.parseCommand(userInput, gameEngine);
                        if (output != null) {
                            System.out.println(output);
                        }
                    } catch (GameException exception) {
                        System.err.println(exception.getMessage());
                    }
                } else {
                    System.out.println(gameEngine.getOutputStream());
                }
            }
        }

        scanner.close();

    }
}
